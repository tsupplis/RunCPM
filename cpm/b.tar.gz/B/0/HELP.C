/*
%CC1 $1.C -X -E5000
%CLINK $1 DIO WILDEXP -N -S
%DELETE $1.CRL 
*/
/*********************************************************************
*                               HELP                                 *
**********************************************************************
*                  COPYRIGHT 1983 EUGENE H. MALLORY                  *
* Converted to Hi-Tech C by John Elliott, 18 November 1998           *
*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <cpm.h>
#include <sys.h>
#include "pipemgr.h"

#define MENUCOUNT 120
#define NOCONTINUE 1 /* Set to 1 if you want to exit at end of section */
char menutext[MENUCOUNT][MAXLINE];
char *menuptrs[MENUCOUNT];
char **menuv,*cprompt,*lprompt;
int menuctr,mindex;
char string[MAXLINE];
char fname[MAXLINE];
char c;
FILE *fp1;
int DIOOUT;
int string_compare(void *s, void *t);

int stdout_piped(void);
int menu(int icounter, char **strings, char *prompt);



int main(int argc, char **argv)
{
    int i,menuflag;
    char **fvectorp;
    char *disk;
    int diskno,vctr;

    DIOOUT = stdout_piped();

    menuflag = 0;
    cprompt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    lprompt = "abcdefghijklmnopqrstuvwxyz";
    init_args(&argc, &argv);
    if (argc != 2)
    {
	disk = "ABCDEFGHIJKLMNOP";
	vctr = 3;
	diskno = bdos(25);
      	if (!diskno) vctr = 2;
	sprintf(string, "%c:*.HLP %s", disk[diskno], diskno ? "A:*.HLP" : "");
	fvectorp = _getargs(string, "HELP");
        vctr     = _argc_;
        init_args(&argc, &argv);
	qsort(&fvectorp[1],vctr-1,sizeof(char *), string_compare);
	fvectorp++;
	filemenu:
	i = menu(vctr-1,fvectorp,cprompt);
	if (i == -1) goto exithelp;
	strcpy(fname,fvectorp[i]);
	fp1 = fopen(fname, "r");
	if (!fp1)
	{
            fprintf(stderr, "HELP: Unable to open %s", fname);
            exit(1);  
        }
	menuflag = 1;
    }
    else
    {
	strcpy(fname,argv[1]);
	strcat(fname,".hlp");
	fp1 = fopen(fname, "r");
	if (!fp1) 
	{
	    strcpy(fname,"a:");
	    strcat(fname,argv[1]);
	    strcat(fname,".hlp");
	    fp1 = fopen(fname, "r");
	}
	if (!fp1) 
	{ 
            fprintf(stderr, "HELP: Unable to find help for: %s. \n",fname);
            exit(1);
	}
    }
    if (!fgets(string, MAXLINE, fp1))
    {
	fprintf(stderr, "HELP: Help file %s empty.",fname);
    }
    menuctr = 0;
    for (i=0;i<MENUCOUNT;i++) menuptrs[i] = &menutext[i];
    menuv = &menuptrs[0];
    if (string[0] == ':')
    {
	/* Non indexed file, build index */
	do
	{
	    string[strlen(string)-1] = 0;
	    if (string[0] == ':')
	    strcpy(menutext[menuctr++],string);
	    if (menuctr == MENUCOUNT) break;
	}
	while (fgets(string, MAXLINE, fp1));
/*	fclose(fp1);
	fp1 = fopen(fname, "r");
*/      fseek(fp1, 0, 0);
	fgets(string, MAXLINE, fp1);
    }
    else
    {
	/* Indexed file, build index */
	do
	{
	    string[strlen(string)-1] = 0;
	    strcpy(menutext[menuctr++],string);
	    if (!fgets(string, MAXLINE, fp1) || menuctr == MENUCOUNT)
	    {
		/* No colons and no index. */
/*		fclose(fp1);
		fp1 = fopen(fname, "r");
*/              fseek(fp1, 0, 0);
		fprintf(stderr,"\n\014");
		string[0] = ':';
		fgets(&string[1], MAXLINE, fp1);
		helprint(!menuflag);
		if (menuflag) goto filemenu;
		goto exithelp;
	    }
	}
	while (string[0] != ':');
    }
/****************************************************************
*  	Now, index is built and the first line read		*
*	past the index.						*
****************************************************************/
    again:
    if (menuctr == 1) /* if only one choice */
    {
	helprint(0);
	if (menuflag) goto filemenu;
	else goto exithelp;
    }
    mindex=menu(menuctr,menuv,lprompt);
    if (mindex == -1 && menuflag) goto filemenu;
    if (mindex == -1) goto exithelp;
    while (mindex)
    {
	if (!fgets(string, MAXLINE, fp1))
	{
	    fprintf(stderr, "HELP: Ran off end of help file while searching.");
	}
	if (string[0] == ':') mindex--;
    }
    helprint(0);
/*  fclose(fp1);
    fopen(fname, "r");
*/  fseek(fp1, 0, 0);

    while (fgets(string, MAXLINE, fp1))
    {
	if (string[0] == ':') break;
    }
    goto again;
exithelp:
    fclose(fp1);
}

helprint(exitflag)
int exitflag;
{
    char c;
    int lctr,noteof;
    printmore:
    if (DIOOUT) fputs(&string[1], stdout);
    fprintf(stderr,"%s",&string[1]);
    lctr = 1;
    while (noteof = (fgets(string, MAXLINE, fp1) != NULL))
    {
	if (string[0] == ':') break;
	lctr++;
	if ((string[0] == '\014' || string[0] == ';' || lctr == 21))
	{
	    lctr = 0;
	    fprintf(stderr,"\n(More available, hit CR to continue, ESC to quit.)\n");
	    c = bdos(1)&0xff;
	    if (c == '\003') exit(0);  	/* CTL C */
	    if (c == '\033') goto quit;
	    fprintf(stderr,"\n\014");
	    if (string[0] == '\014' || string[0] == ';') 
	    {
		if (DIOOUT) fputs(&string[1], stdout);
		fputs(&string[1], stderr);
		lctr++;
	    }
	    else
	    {
		if (DIOOUT) fputs(string, stdout);
		fputs(string, stderr);
	    }
	    continue;
	}
	if (DIOOUT) fputs(string, stdout);
	fputs(string, stderr);
    }
    if (exitflag) goto quit;
    if (!noteof) 
    fprintf(stderr,"\n(End of file, CR to return to menu.)\n");
    else if (NOCONTINUE)
    fprintf(stderr,"\n(End of section, CR to return to menu.)\n");
    else
    fprintf(stderr,"\n(End of section, CR to continue, ESC to quit.)\n");
    c = bdos(1)&0xff;
    if (c == '\003') exit(0);  	/* CTL C */
    if (c == '\033' || !noteof || NOCONTINUE) 
    {
	quit: 
	return;
    }
    fprintf(stderr,"\n\014");
    goto printmore;
}

int menu(int icounter, char **strings, char *prompt)
{
    int max,bias,i,j;
    bias = 0;
    lup:
    fprintf(stderr,"\n\014");
    if ((icounter-bias) > 26) max = 26;
    else max = icounter-bias;
    for (i=0;i<(max+1)/2;i++)
    {
	fprintf(stderr,"%c) %s",prompt[i],strings[i+bias]);
	if (i+bias+(max+1)/2 < icounter)
	{
	    for (j=0;j<=37-strlen(strings[i+bias]);j++) fprintf(stderr," ");
	    fprintf(stderr,"%c) %s\n",
	    prompt[i+(max+1)/2],
	    strings[i+bias+(max+1)/2]);
	}
	else fprintf(stderr,"\n");
    }
    fprintf(stderr,"\n\n");
    if (icounter > bias+26)
    fprintf(stderr,"More selections are available.\n");
    fprintf(stderr,"Type selection, ESC to exit, CR for more, - to backup :");
    c = bdos(1);
    fprintf(stderr,"char is %x\n\014",c);
    if (c == '\003') exit(0);  	/* CTL C */
    if (c == '\033') return -1;  	/* ESC   */
    if (c == '\r' && (icounter > bias+26)) bias += 26;
    else if (c == '\r' && (icounter <= bias+26)) bias = 0;
    if (c == '-') bias -= 26;
    if (bias == -26) bias = icounter-26;
    if (bias < 0) bias = 0;
    if (!isalpha(c)) goto lup;
    for (i=0;safe_toupper(c)!=safe_toupper(prompt[i]);i++);
    if (i>=max) goto lup;
    if (i+bias >= icounter) goto lup;
    return i+bias;
}

int string_compare(void *s, void *t)
{
    char *s1, *t1;
    int i;
    s1 = *(char **)s;
    t1 = *(char **)t;
    for (i=0;i<MAXLINE;i++)
    {
	if (t1[i] != s1[i]) 
	return s1[i] - t1[i];
	if (s1[i] == '\0') return 0;
    }
    return 0;
}


struct
{
      char func;
      char npars;
      char *txt;
} pcb2 = {0x76, 1, "PIPEMGR "};


int stdout_piped(void)
{
      if (!_piped) return 0;

      return (bdoshl(0x3C, &pcb2) & 0x200);
}
